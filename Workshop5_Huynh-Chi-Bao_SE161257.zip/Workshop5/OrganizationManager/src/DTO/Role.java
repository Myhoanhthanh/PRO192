package DTO;

/**
 *
 * @author baohc
 */
public interface Role {
    public void createWorker();
}
